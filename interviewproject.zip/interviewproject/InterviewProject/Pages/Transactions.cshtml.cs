using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InterviewProject.Data;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InterviewProject.Pages
{
    public class TransactionsModel : PageModel
    {
        public ApplicationDbContext Context { get; set; }
        public List<TransactionViewModel> Transactions { get; set; }
        public List<SalesViewModel> Sales { get; set; }
        public List<ProductsViewModel> Products { get; set; }
        public TransactionsModel(ApplicationDbContext context)
        {
            Context = context;
        }
        public void OnGet()
        {
            Transactions = Context.CustomerTransactions.Select(x => new TransactionViewModel
            {
                Id = x.Id,
                TransactionDate = x.TransactionDate,
            }).ToList();

            Sales = Context.Sales.Select(x => new SalesViewModel
            {
                Id = x.Id,
                CustomerTransactionId = x.CustomerTranscationId,
                ProductId = x.ProductId,
                PricePaid = x.PricePaid,
            }).ToList();

            Products = Context.Products.Select(x => new ProductsViewModel
            {
                Id = x.Id,
                CurrentPrice = x.CurrentPrice,
                Cost = x.Cost,
            }).ToList();
        }
        public class TransactionViewModel
        {
            public int Id { get; set; }
            public DateTime TransactionDate { get; set; }
        }

        public class SalesViewModel
        {
            public int Id { get; set; }
            public int CustomerTransactionId { get; set; }
            public int ProductId { get; set; }
            public decimal PricePaid { get; set; }
        }

        public class ProductsViewModel
        {
            public int Id { get; set; }
            public decimal CurrentPrice { get; set; }
            public decimal Cost { get; set; }
        }
    }
}