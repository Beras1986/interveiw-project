using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using InterviewProject.Data;
using InterviewProject.Data.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace InterviewProject.Pages.Shared
{
    public class ProductModel : PageModel
    {
        public ApplicationDbContext Context { get; set; }
        public ProductModel(ApplicationDbContext context)
        {
            Context = context;
        }
        [BindProperty]
        public ProductViewModel Product { get; set; }
        public List<CategoriesList> Categories { get; set; }
        public IActionResult OnGet(int id = -1)
        {

            Categories = Context.ProductCategories.Select(x => new CategoriesList
            {
                Value = x.Id,
                Text = x.Name,
            }).ToList();

            if (id == -1)
            {
                Product = new ProductViewModel
                {
                    Name = "",
                    CurrentPrice = 0.01m,
                };
            }
            else
            {
                Product = Context.Products.Where(x => x.Id == id)
                    .Select(x => new ProductViewModel
                    {
                        Name = x.Name,
                        CurrentPrice = x.CurrentPrice,
                        Cost = x.Cost,
                        QuantityInStock = x.QuantityInStock,
                        Barcode = x.Barcode,
                        Manufacturer = x.Manufacturer,
                        ProductCategoryId = x.ProductCategoryId,
                    }).FirstOrDefault();

                if (Product == null) return NotFound();
            }

            return Page();
        }
        public IActionResult OnPost(int id)
        {
            if (Product == null) return NotFound();

            if (ModelState.IsValid)
            {
                if (id == -1)
                {
                    // Create new entry

                    var product = new Product
                    {
                        Name = Product.Name,
                        QuantityInStock = Product.QuantityInStock,
                        Cost = Product.Cost,
                        CurrentPrice = Product.CurrentPrice,
                        Barcode = Product.Barcode,
                        Manufacturer = Product.Manufacturer,
                        ProductCategoryId = Int32.Parse(Request.Form["category"]),

                };

                    Context.Add(product);
                    Context.SaveChanges();

                    if (product.Id > 0)
                    {
                        return RedirectToPage("Products");
                        //return RedirectToPage("Product", new { id = product.Id });
                    } else
                    {
                        // Error handling
                    }
                } else
                {
                    // Update
                    var currentEntry = Context.Products.Where(x => x.Id == id).FirstOrDefault();

                    if (currentEntry == null) return NotFound();

                    currentEntry.Name = Product.Name;
                    currentEntry.Cost = Product.Cost;
                    currentEntry.CurrentPrice = Product.CurrentPrice;
                    currentEntry.QuantityInStock = Product.QuantityInStock;
                    currentEntry.Barcode = Product.Barcode;
                    currentEntry.Manufacturer = Product.Manufacturer;
                    currentEntry.ProductCategoryId = Int32.Parse(Request.Form["category"]);

                    Context.SaveChanges();
                    return RedirectToPage("Products");
                }
            }
            return Page();
        }

        public class ProductViewModel
        {
            [Required]
            [MinLength(1)]
            public string Name { get; set; }


            [DisplayName("Current Price")]
            [Range(0,double.MaxValue)]
            public decimal CurrentPrice { get; set; }


            [Range(0, double.MaxValue)]
            public decimal Cost { get; set; }


            [Range(0, int.MaxValue)]
            [DisplayName("Quantity in Stock")]
            public int QuantityInStock { get; set; }

            [Required]
            [MinLength(1)]
            public string Barcode { get; set; }

            [Required]
            [MinLength(1)]
            public string Manufacturer { get; set; }

            public int ProductCategoryId { get; set; }
        }

        public class CategoriesList
        {
            [Required]
            [MinLength(1)]
            public string Text { get; set; }

            public int Value { get; set; }
        }
    }
}
