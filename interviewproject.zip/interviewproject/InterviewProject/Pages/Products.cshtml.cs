using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InterviewProject.Data;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InterviewProject.Pages
{
    public class ProductsPageModel : PageModel
    {
        public ApplicationDbContext Context { get; set; }
        public List<ProductViewModel> Products { get; set; }
        public List<ProductCategoryViewModel> Categories { get; set; }
        public ProductsPageModel(ApplicationDbContext context)
        {
            Context = context;
        }
        public void OnGet()
        {
            Products = Context.Products.Select(x => new ProductViewModel { 
                Id = x.Id,
                Name = x.Name,
                ProductCategoryId = x.ProductCategoryId,
                Price = x.CurrentPrice,
                QuantityInStock = x.QuantityInStock,
                Barcode = x.Barcode,
                Manufacturer = x.Manufacturer,
            }).ToList();

            Categories = Context.ProductCategories.Select(x => new ProductCategoryViewModel
            {
                Id = x.Id,
                Name = x.Name,
            }).ToList();
        }

        public class ProductViewModel
        {
            public int Id { get; set; }
            public int QuantityInStock { get; set; }
            public decimal Price { get; set; }
            public string Name { get; set; }

            public int ProductCategoryId { get; set; }
            public string Barcode { get; set; }
            public string Manufacturer { get; set; }
        }

        public class ProductCategoryViewModel
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
    }
}
