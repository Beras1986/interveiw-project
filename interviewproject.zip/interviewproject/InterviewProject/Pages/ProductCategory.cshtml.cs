using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using InterviewProject.Data;
using InterviewProject.Data.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InterviewProject.Pages
{
    public class ProductCategoryModel : PageModel
    {
        public ApplicationDbContext Context { get; set; }
        public ProductCategoryModel(ApplicationDbContext context)
        {
            Context = context;
        }
        [BindProperty]
        public ProductCategoryViewModel ProductCategory { get; set; }
        public IActionResult OnGet(int id = -1)
        {
            if (id == -1)
            {
                ProductCategory = new ProductCategoryViewModel
                {
                    Name = "",
                };
            }
            else
            {
                ProductCategory = Context.ProductCategories.Where(x => x.Id == id)
                    .Select(x => new ProductCategoryViewModel
                    {
                        Name = x.Name,
                    }).FirstOrDefault();

                if (ProductCategory == null) return NotFound();
            }

            return Page();
        }

        public IActionResult OnPost(int id)
        {
            if (ProductCategory == null) return NotFound();

            if (ModelState.IsValid)
            {
                if (id == -1)
                {
                    // Create new entry

                    var productCategory = new ProductCategory
                    {
                        Name = ProductCategory.Name,
                    };

                    Context.Add(productCategory);
                    Context.SaveChanges();

                    if (productCategory.Id > 0)
                    {
                        return RedirectToPage("ProductCategories");
                        //return RedirectToPage("Product", new { id = product.Id });
                    }
                    else
                    {
                        // Error handling
                    }
                }
                else
                {
                    // Update
                    var currentEntry = Context.ProductCategories.Where(x => x.Id == id).FirstOrDefault();

                    if (currentEntry == null) return NotFound();

                    currentEntry.Name = ProductCategory.Name;

                    Context.SaveChanges();
                    return RedirectToPage("ProductCategories");
                }
            }
            return Page();
        }

        public class ProductCategoryViewModel
        {
            [Required]
            [MinLength(1)]
            public string Name { get; set; }
        }
    }
}
