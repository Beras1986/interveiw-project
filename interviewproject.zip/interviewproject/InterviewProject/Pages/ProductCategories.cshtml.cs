using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InterviewProject.Data;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InterviewProject.Pages
{
    public class ProductCategoriesModel : PageModel
    {
        public ApplicationDbContext Context { get; set; }
        public List<ProductCatgoriesViewModel> Categories { get; set; }
        public ProductCategoriesModel(ApplicationDbContext context)
        {
            Context = context;
        }
        public void OnGet()
        {
            Categories = Context.ProductCategories.Select(x => new ProductCatgoriesViewModel
            {
                Id = x.Id,
                Name = x.Name,
            }).ToList();
        }

        public class ProductCatgoriesViewModel
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
    }
}
