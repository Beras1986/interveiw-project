﻿using System;
using System.Collections.Generic;
using System.Text;
using InterviewProject.Data.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace InterviewProject.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<CustomerTransaction> CustomerTransactions { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public static readonly DateTime SeedTime = new DateTime(2020, 02, 24);
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ProductCategory>().HasData(
                new ProductCategory { Id = 1, Name = "Miscellaneous"}
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Apple", CurrentPrice = 0.20m, Cost = 0.13m, QuantityInStock=56},
                new Product { Id = 2, Name = "Orange", CurrentPrice = 0.10m, Cost = 0.07m, QuantityInStock=50 },
                new Product { Id = 3, Name = "2L Milk Bottle", CurrentPrice = 1.00m, Cost = 0.93m, QuantityInStock = 33 },
                new Product { Id = 4, Name = "Strawberry Yogurt", CurrentPrice = 3.10m, Cost = 2.05m, QuantityInStock = 2 },
                new Product { Id = 5, Name = "Cheese Block", CurrentPrice = 1.70m, Cost = 1.12m, QuantityInStock = 8 }
            );

            modelBuilder.Entity<CustomerTransaction>().HasData(
                new CustomerTransaction { Id = 1, TransactionDate = SeedTime.AddDays(1).AddHours(11).AddMinutes(11) },
                new CustomerTransaction { Id = 2, TransactionDate = SeedTime.AddDays(1).AddHours(11).AddMinutes(34) },
                new CustomerTransaction { Id = 3, TransactionDate = SeedTime.AddDays(0).AddHours(15).AddMinutes(35) }
            );

            modelBuilder.Entity<Sale>().HasData(
                new Sale { Id = 1, ProductId = 1, CustomerTranscationId = 1, PricePaid = 0.20m },
                new Sale { Id = 2, ProductId = 1, CustomerTranscationId = 1, PricePaid = 0.20m },
                new Sale { Id = 3, ProductId = 1, CustomerTranscationId = 1, PricePaid = 0.20m },
                new Sale { Id = 4, ProductId = 2, CustomerTranscationId = 2, PricePaid = 0.10m },
                new Sale { Id = 5, ProductId = 2, CustomerTranscationId = 2, PricePaid = 0.10m },
                new Sale { Id = 6, ProductId = 3, CustomerTranscationId = 2, PricePaid = 0.93m },
                new Sale { Id = 7, ProductId = 4, CustomerTranscationId = 3, PricePaid = 3.10m },
                new Sale { Id = 8, ProductId = 1, CustomerTranscationId = 3, PricePaid = 0.20m },
                new Sale { Id = 9, ProductId = 1, CustomerTranscationId = 3, PricePaid = 0.20m }
            );

            //var hasher = new PasswordHasher<IdentityUser<string>>();
            modelBuilder.Entity<IdentityUser>().HasData(
                new IdentityUser()
                {
                    Id = "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC",
                    UserName = "admin",
                    NormalizedUserName = "admin",
                    Email = "noreply@banksidesystems.co.uk",
                    NormalizedEmail = "noreply@banksidesystems.co.uk",
                    EmailConfirmed = true,
                    // Seed fixed salt as to avoid constantly updating password every migration!
                    //PasswordHash = hasher.HashPassword(null, "password123"),
                    PasswordHash = "AQAAAAEAACcQAAAAEIltE05GCI+EM2WXNespGTgsH70WhE0vHKMTbqDXJjAUM4q6DfFO1ZxLTBbILlZIrQ==",
                    SecurityStamp = string.Empty,
                    ConcurrencyStamp = "29D7C852-00E4-47F7-BA60-16F123806255",
                },
                new IdentityUser()
                {
                    Id = "50EB2B35-B452-4D57-9514-15E07A4B16C1",
                    UserName = "staff",
                    NormalizedUserName = "staff",
                    Email = "noreply@banksidesystems.co.uk",
                    NormalizedEmail = "noreply@banksidesystems.co.uk",
                    EmailConfirmed = true,
                    // Seed fixed salt as to avoid constantly updating password every migration!
                    //PasswordHash = hasher.HashPassword(null, "password123"),
                    PasswordHash = "AQAAAAEAACcQAAAAEHwUfdxzzoZmjCUIriijSGloRVQBITUxbnDjDz46fEdTZ4Qdahs1wqoCCl3sLHer/Q==",
                    SecurityStamp = string.Empty,
                    ConcurrencyStamp = "50EB2B35-B452-4D57-9514-15E07A4B16C1",
                },
                new IdentityUser()
                {
                    Id = "A6070AE6-B83F-4810-9466-1A30535F5264",
                    UserName = "shopper",
                    NormalizedUserName = "shopper",
                    Email = "noreply@banksidesystems.co.uk",
                    NormalizedEmail = "noreply@banksidesystems.co.uk",
                    EmailConfirmed = true,
                    // Seed fixed salt as to avoid constantly updating password every migration!
                    //PasswordHash = hasher.HashPassword(null, "password123"),
                    PasswordHash = "AQAAAAEAACcQAAAAEJCvzr+GJjdrziX4q/+zO8GJ6RAjpU/uMAqKP0aHg+KD4r1BpITHEqXHHqd/NIMHvA==",
                    SecurityStamp = string.Empty,
                    ConcurrencyStamp = "5B827C08-B120-4127-80CA-5A66D127A20A",
                }
            );
            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole
                {
                    Id = "85B4D3C6-EB38-4407-8C72-78AA709DEDDA",
                    Name = "staff",
                    NormalizedName = "staff",
                    ConcurrencyStamp = "D1DA7302-4B4F-4BD9-9656-E57A141D63B6",
                },
                new IdentityRole
                {
                    Id = "CC3B26CE-9615-4A0B-9C1F-6BB7C14DF0C7",
                    Name = "admin",
                    NormalizedName = "admin",
                    ConcurrencyStamp = "27796E95-DF7D-4260-A3F7-9A448C039BC2",
                }
            );
            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string>()
                {
                    UserId = "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", // admin user
                    RoleId = "CC3B26CE-9615-4A0B-9C1F-6BB7C14DF0C7" // admin role
                },
                new IdentityUserRole<string>()
                {
                    UserId = "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", // admin user
                    RoleId = "85B4D3C6-EB38-4407-8C72-78AA709DEDDA" // staff role
                }
            );
        }
    }
}
