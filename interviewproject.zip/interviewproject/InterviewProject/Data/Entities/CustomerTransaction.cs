﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterviewProject.Data.Entities
{
    public class CustomerTransaction
    {
        public int Id { get; set; }
        public string LoyaltyNumber { get; set; }
        public DateTime TransactionDate { get; set; }
        public List<Sale> Sales { get; set; }
    }
}
