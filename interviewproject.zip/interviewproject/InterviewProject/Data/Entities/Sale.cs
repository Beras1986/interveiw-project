﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InterviewProject.Data.Entities
{
    public class Sale
    {
        [Key]
        public int Id { get; set; }

        public int ProductId { get; set; }
        public Product Product { get; set; }
        public int CustomerTranscationId { get; set; }
        public CustomerTransaction CustomerTransaction { get; set; }

        // Associate with SQL Server decimal precision.
        [Column(TypeName = "decimal(18,2)")]
        public decimal PricePaid { get; set; }
    }
}
