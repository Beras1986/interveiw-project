﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace InterviewProject.Data.Migrations
{
    public partial class AddUsersAndRoles : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "85B4D3C6-EB38-4407-8C72-78AA709DEDDA", "D1DA7302-4B4F-4BD9-9656-E57A141D63B6", "staff", "staff" },
                    { "CC3B26CE-9615-4A0B-9C1F-6BB7C14DF0C7", "27796E95-DF7D-4260-A3F7-9A448C039BC2", "admin", "admin" }
                });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", 0, "29D7C852-00E4-47F7-BA60-16F123806255", "noreply@banksidesystems.co.uk", true, false, null, "noreply@banksidesystems.co.uk", "admin", "AQAAAAEAACcQAAAAEIltE05GCI+EM2WXNespGTgsH70WhE0vHKMTbqDXJjAUM4q6DfFO1ZxLTBbILlZIrQ==", null, false, "", false, "admin" },
                    { "50EB2B35-B452-4D57-9514-15E07A4B16C1", 0, "50EB2B35-B452-4D57-9514-15E07A4B16C1", "noreply@banksidesystems.co.uk", true, false, null, "noreply@banksidesystems.co.uk", "staff", "AQAAAAEAACcQAAAAEHwUfdxzzoZmjCUIriijSGloRVQBITUxbnDjDz46fEdTZ4Qdahs1wqoCCl3sLHer/Q==", null, false, "", false, "staff" },
                    { "A6070AE6-B83F-4810-9466-1A30535F5264", 0, "5B827C08-B120-4127-80CA-5A66D127A20A", "noreply@banksidesystems.co.uk", true, false, null, "noreply@banksidesystems.co.uk", "shopper", "AQAAAAEAACcQAAAAEJCvzr+GJjdrziX4q/+zO8GJ6RAjpU/uMAqKP0aHg+KD4r1BpITHEqXHHqd/NIMHvA==", null, false, "", false, "shopper" }
                });

            migrationBuilder.InsertData(
                table: "AspNetUserRoles",
                columns: new[] { "UserId", "RoleId" },
                values: new object[] { "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", "CC3B26CE-9615-4A0B-9C1F-6BB7C14DF0C7" });

            migrationBuilder.InsertData(
                table: "AspNetUserRoles",
                columns: new[] { "UserId", "RoleId" },
                values: new object[] { "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", "85B4D3C6-EB38-4407-8C72-78AA709DEDDA" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUserRoles",
                keyColumns: new[] { "UserId", "RoleId" },
                keyValues: new object[] { "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", "85B4D3C6-EB38-4407-8C72-78AA709DEDDA" });

            migrationBuilder.DeleteData(
                table: "AspNetUserRoles",
                keyColumns: new[] { "UserId", "RoleId" },
                keyValues: new object[] { "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC", "CC3B26CE-9615-4A0B-9C1F-6BB7C14DF0C7" });

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "50EB2B35-B452-4D57-9514-15E07A4B16C1");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "A6070AE6-B83F-4810-9466-1A30535F5264");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "85B4D3C6-EB38-4407-8C72-78AA709DEDDA");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "CC3B26CE-9615-4A0B-9C1F-6BB7C14DF0C7");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "88B986A0-CB8B-4F8C-A5D5-5AC62240A3EC");
        }
    }
}
