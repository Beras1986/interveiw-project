﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace InterviewProject.Data.Migrations
{
    public partial class CreateSupermarketEntities : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CustomerTransactions",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LoyaltyNumber = table.Column<string>(nullable: true),
                    TransactionDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerTransactions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    QuantityInStock = table.Column<int>(nullable: false),
                    CurrentPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Cost = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Sales",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductId = table.Column<int>(nullable: false),
                    CustomerTranscationId = table.Column<int>(nullable: false),
                    CustomerTransactionId = table.Column<int>(nullable: true),
                    PricePaid = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sales", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sales_CustomerTransactions_CustomerTransactionId",
                        column: x => x.CustomerTransactionId,
                        principalTable: "CustomerTransactions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Sales_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "CustomerTransactions",
                columns: new[] { "Id", "LoyaltyNumber", "TransactionDate" },
                values: new object[,]
                {
                    { 1, null, new DateTime(2020, 2, 25, 11, 11, 0, 0, DateTimeKind.Unspecified) },
                    { 2, null, new DateTime(2020, 2, 25, 11, 34, 0, 0, DateTimeKind.Unspecified) },
                    { 3, null, new DateTime(2020, 2, 24, 15, 35, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "Cost", "CurrentPrice", "Name", "QuantityInStock" },
                values: new object[,]
                {
                    { 1, 0.13m, 0.20m, "Apple", 56 },
                    { 2, 0.07m, 0.10m, "Orange", 50 },
                    { 3, 0.93m, 1.00m, "2L Milk Bottle", 33 },
                    { 4, 2.05m, 3.10m, "Strawberry Yogurt", 2 },
                    { 5, 1.12m, 1.70m, "Cheese Block", 8 }
                });

            migrationBuilder.InsertData(
                table: "Sales",
                columns: new[] { "Id", "CustomerTransactionId", "CustomerTranscationId", "PricePaid", "ProductId" },
                values: new object[,]
                {
                    { 1, null, 1, 0.20m, 1 },
                    { 2, null, 1, 0.20m, 1 },
                    { 3, null, 1, 0.20m, 1 },
                    { 8, null, 3, 0.20m, 1 },
                    { 9, null, 3, 0.20m, 1 },
                    { 4, null, 2, 0.10m, 2 },
                    { 5, null, 2, 0.10m, 2 },
                    { 6, null, 2, 0.93m, 3 },
                    { 7, null, 3, 3.10m, 4 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Sales_CustomerTransactionId",
                table: "Sales",
                column: "CustomerTransactionId");

            migrationBuilder.CreateIndex(
                name: "IX_Sales_ProductId",
                table: "Sales",
                column: "ProductId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Sales");

            migrationBuilder.DropTable(
                name: "CustomerTransactions");

            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
